﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCliente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCliente))
        Me.DataGridViewCliente = New System.Windows.Forms.DataGridView()
        Me.IDClienteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreCDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApPaternoCDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApMaternoCDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DireccionCDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TelefonoCDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IDFacturaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MedicocreaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MedicoactualizaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClienteBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital1DataSet1 = New Hospital.Hospital1DataSet1()
        Me.Hospital1DataSet1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital1DataSet = New Hospital.Hospital1DataSet()
        Me.BtnEliminarC = New System.Windows.Forms.Button()
        Me.BtnActualizarC = New System.Windows.Forms.Button()
        Me.BtnAgregar = New System.Windows.Forms.Button()
        Me.TxtNombreC = New System.Windows.Forms.TextBox()
        Me.TxtApC = New System.Windows.Forms.TextBox()
        Me.TxtAmC = New System.Windows.Forms.TextBox()
        Me.TxtDireccionC = New System.Windows.Forms.TextBox()
        Me.TxtTelC = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ClienteTableAdapter = New Hospital.Hospital1DataSetTableAdapters.ClienteTableAdapter()
        Me.FacturaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FacturaTableAdapter = New Hospital.Hospital1DataSetTableAdapters.FacturaTableAdapter()
        Me.NotaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital1DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaTableAdapter = New Hospital.Hospital1DataSet1TableAdapters.NotaTableAdapter()
        Me.Hospital1DataSet2 = New Hospital.Hospital1DataSet2()
        Me.NotaBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaTableAdapter1 = New Hospital.Hospital1DataSet2TableAdapters.NotaTableAdapter()
        Me.NotaBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteTableAdapter1 = New Hospital.Hospital1DataSet2TableAdapters.ClienteTableAdapter()
        Me.ClienteBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteTableAdapter2 = New Hospital.Hospital1DataSet1TableAdapters.ClienteTableAdapter()
        Me.NotaBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaBindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CBN = New System.Windows.Forms.ComboBox()
        Me.NotaBindingSource9 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital1DataSet3BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Hospital1DataSet3 = New Hospital.Hospital1DataSet3()
        Me.NotaBindingSource8 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaBindingSource6 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaBindingSource7 = New System.Windows.Forms.BindingSource(Me.components)
        Me.NotaTableAdapter2 = New Hospital.Hospital1DataSet3TableAdapters.NotaTableAdapter()
        Me.btnVolver = New System.Windows.Forms.Button()
        CType(Me.DataGridViewCliente, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FacturaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet3BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Hospital1DataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NotaBindingSource7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridViewCliente
        '
        Me.DataGridViewCliente.AutoGenerateColumns = False
        Me.DataGridViewCliente.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridViewCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewCliente.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDClienteDataGridViewTextBoxColumn, Me.NombreCDataGridViewTextBoxColumn, Me.ApPaternoCDataGridViewTextBoxColumn, Me.ApMaternoCDataGridViewTextBoxColumn, Me.DireccionCDataGridViewTextBoxColumn, Me.TelefonoCDataGridViewTextBoxColumn, Me.StatusDataGridViewCheckBoxColumn, Me.IDFacturaDataGridViewTextBoxColumn, Me.MedicocreaDataGridViewTextBoxColumn, Me.MedicoactualizaDataGridViewTextBoxColumn})
        Me.DataGridViewCliente.DataSource = Me.ClienteBindingSource4
        Me.DataGridViewCliente.Location = New System.Drawing.Point(272, 15)
        Me.DataGridViewCliente.Name = "DataGridViewCliente"
        Me.DataGridViewCliente.Size = New System.Drawing.Size(540, 300)
        Me.DataGridViewCliente.TabIndex = 7
        '
        'IDClienteDataGridViewTextBoxColumn
        '
        Me.IDClienteDataGridViewTextBoxColumn.DataPropertyName = "ID_Cliente"
        Me.IDClienteDataGridViewTextBoxColumn.HeaderText = "ID_Cliente"
        Me.IDClienteDataGridViewTextBoxColumn.Name = "IDClienteDataGridViewTextBoxColumn"
        Me.IDClienteDataGridViewTextBoxColumn.ReadOnly = True
        '
        'NombreCDataGridViewTextBoxColumn
        '
        Me.NombreCDataGridViewTextBoxColumn.DataPropertyName = "NombreC"
        Me.NombreCDataGridViewTextBoxColumn.HeaderText = "NombreC"
        Me.NombreCDataGridViewTextBoxColumn.Name = "NombreCDataGridViewTextBoxColumn"
        '
        'ApPaternoCDataGridViewTextBoxColumn
        '
        Me.ApPaternoCDataGridViewTextBoxColumn.DataPropertyName = "ApPaternoC"
        Me.ApPaternoCDataGridViewTextBoxColumn.HeaderText = "ApPaternoC"
        Me.ApPaternoCDataGridViewTextBoxColumn.Name = "ApPaternoCDataGridViewTextBoxColumn"
        '
        'ApMaternoCDataGridViewTextBoxColumn
        '
        Me.ApMaternoCDataGridViewTextBoxColumn.DataPropertyName = "ApMaternoC"
        Me.ApMaternoCDataGridViewTextBoxColumn.HeaderText = "ApMaternoC"
        Me.ApMaternoCDataGridViewTextBoxColumn.Name = "ApMaternoCDataGridViewTextBoxColumn"
        '
        'DireccionCDataGridViewTextBoxColumn
        '
        Me.DireccionCDataGridViewTextBoxColumn.DataPropertyName = "DireccionC"
        Me.DireccionCDataGridViewTextBoxColumn.HeaderText = "DireccionC"
        Me.DireccionCDataGridViewTextBoxColumn.Name = "DireccionCDataGridViewTextBoxColumn"
        '
        'TelefonoCDataGridViewTextBoxColumn
        '
        Me.TelefonoCDataGridViewTextBoxColumn.DataPropertyName = "TelefonoC"
        Me.TelefonoCDataGridViewTextBoxColumn.HeaderText = "TelefonoC"
        Me.TelefonoCDataGridViewTextBoxColumn.Name = "TelefonoCDataGridViewTextBoxColumn"
        '
        'StatusDataGridViewCheckBoxColumn
        '
        Me.StatusDataGridViewCheckBoxColumn.DataPropertyName = "Status"
        Me.StatusDataGridViewCheckBoxColumn.HeaderText = "Status"
        Me.StatusDataGridViewCheckBoxColumn.Name = "StatusDataGridViewCheckBoxColumn"
        '
        'IDFacturaDataGridViewTextBoxColumn
        '
        Me.IDFacturaDataGridViewTextBoxColumn.DataPropertyName = "ID_Factura"
        Me.IDFacturaDataGridViewTextBoxColumn.HeaderText = "ID_Factura"
        Me.IDFacturaDataGridViewTextBoxColumn.Name = "IDFacturaDataGridViewTextBoxColumn"
        '
        'MedicocreaDataGridViewTextBoxColumn
        '
        Me.MedicocreaDataGridViewTextBoxColumn.DataPropertyName = "Medico_crea"
        Me.MedicocreaDataGridViewTextBoxColumn.HeaderText = "Medico_crea"
        Me.MedicocreaDataGridViewTextBoxColumn.Name = "MedicocreaDataGridViewTextBoxColumn"
        '
        'MedicoactualizaDataGridViewTextBoxColumn
        '
        Me.MedicoactualizaDataGridViewTextBoxColumn.DataPropertyName = "Medico_actualiza"
        Me.MedicoactualizaDataGridViewTextBoxColumn.HeaderText = "Medico_actualiza"
        Me.MedicoactualizaDataGridViewTextBoxColumn.Name = "MedicoactualizaDataGridViewTextBoxColumn"
        '
        'ClienteBindingSource4
        '
        Me.ClienteBindingSource4.DataMember = "Cliente"
        Me.ClienteBindingSource4.DataSource = Me.Hospital1DataSet1
        '
        'Hospital1DataSet1
        '
        Me.Hospital1DataSet1.DataSetName = "Hospital1DataSet1"
        Me.Hospital1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Hospital1DataSet1BindingSource
        '
        Me.Hospital1DataSet1BindingSource.DataSource = Me.Hospital1DataSet1
        Me.Hospital1DataSet1BindingSource.Position = 0
        '
        'ClienteBindingSource
        '
        Me.ClienteBindingSource.DataMember = "Cliente"
        Me.ClienteBindingSource.DataSource = Me.Hospital1DataSet
        '
        'Hospital1DataSet
        '
        Me.Hospital1DataSet.DataSetName = "Hospital1DataSet"
        Me.Hospital1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BtnEliminarC
        '
        Me.BtnEliminarC.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEliminarC.Location = New System.Drawing.Point(668, 326)
        Me.BtnEliminarC.Name = "BtnEliminarC"
        Me.BtnEliminarC.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminarC.TabIndex = 6
        Me.BtnEliminarC.Text = "Eliminar"
        Me.BtnEliminarC.UseVisualStyleBackColor = True
        '
        'BtnActualizarC
        '
        Me.BtnActualizarC.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnActualizarC.Location = New System.Drawing.Point(587, 326)
        Me.BtnActualizarC.Name = "BtnActualizarC"
        Me.BtnActualizarC.Size = New System.Drawing.Size(75, 23)
        Me.BtnActualizarC.TabIndex = 5
        Me.BtnActualizarC.Text = "Actualizar"
        Me.BtnActualizarC.UseVisualStyleBackColor = True
        '
        'BtnAgregar
        '
        Me.BtnAgregar.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAgregar.Location = New System.Drawing.Point(497, 326)
        Me.BtnAgregar.Name = "BtnAgregar"
        Me.BtnAgregar.Size = New System.Drawing.Size(75, 23)
        Me.BtnAgregar.TabIndex = 4
        Me.BtnAgregar.Text = "Agregar"
        Me.BtnAgregar.UseVisualStyleBackColor = True
        '
        'TxtNombreC
        '
        Me.TxtNombreC.Location = New System.Drawing.Point(27, 75)
        Me.TxtNombreC.Name = "TxtNombreC"
        Me.TxtNombreC.Size = New System.Drawing.Size(209, 20)
        Me.TxtNombreC.TabIndex = 10
        '
        'TxtApC
        '
        Me.TxtApC.Location = New System.Drawing.Point(27, 125)
        Me.TxtApC.Name = "TxtApC"
        Me.TxtApC.Size = New System.Drawing.Size(209, 20)
        Me.TxtApC.TabIndex = 11
        '
        'TxtAmC
        '
        Me.TxtAmC.Location = New System.Drawing.Point(27, 171)
        Me.TxtAmC.Name = "TxtAmC"
        Me.TxtAmC.Size = New System.Drawing.Size(209, 20)
        Me.TxtAmC.TabIndex = 12
        '
        'TxtDireccionC
        '
        Me.TxtDireccionC.Location = New System.Drawing.Point(27, 214)
        Me.TxtDireccionC.Name = "TxtDireccionC"
        Me.TxtDireccionC.Size = New System.Drawing.Size(209, 20)
        Me.TxtDireccionC.TabIndex = 13
        '
        'TxtTelC
        '
        Me.TxtTelC.Location = New System.Drawing.Point(136, 250)
        Me.TxtTelC.Name = "TxtTelC"
        Me.TxtTelC.Size = New System.Drawing.Size(100, 20)
        Me.TxtTelC.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 17)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Nombre:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(24, 105)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 17)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Apellido Paterno:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(24, 151)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 17)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Apellido Materno:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(26, 194)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 17)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Direccion:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(26, 250)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(62, 17)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Telefono:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(26, 286)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(103, 17)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Emision Factura:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(23, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(90, 23)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "CLIENTES"
        '
        'ClienteTableAdapter
        '
        Me.ClienteTableAdapter.ClearBeforeFill = True
        '
        'FacturaBindingSource
        '
        Me.FacturaBindingSource.DataMember = "Factura"
        Me.FacturaBindingSource.DataSource = Me.Hospital1DataSet
        '
        'FacturaTableAdapter
        '
        Me.FacturaTableAdapter.ClearBeforeFill = True
        '
        'NotaBindingSource
        '
        Me.NotaBindingSource.DataMember = "Nota"
        Me.NotaBindingSource.DataSource = Me.Hospital1DataSet1
        '
        'Hospital1DataSetBindingSource
        '
        Me.Hospital1DataSetBindingSource.DataSource = Me.Hospital1DataSet
        Me.Hospital1DataSetBindingSource.Position = 0
        '
        'NotaTableAdapter
        '
        Me.NotaTableAdapter.ClearBeforeFill = True
        '
        'Hospital1DataSet2
        '
        Me.Hospital1DataSet2.DataSetName = "Hospital1DataSet2"
        Me.Hospital1DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'NotaBindingSource1
        '
        Me.NotaBindingSource1.DataMember = "Nota"
        Me.NotaBindingSource1.DataSource = Me.Hospital1DataSet2
        '
        'NotaTableAdapter1
        '
        Me.NotaTableAdapter1.ClearBeforeFill = True
        '
        'NotaBindingSource2
        '
        Me.NotaBindingSource2.DataMember = "Nota"
        Me.NotaBindingSource2.DataSource = Me.Hospital1DataSet2
        '
        'ClienteBindingSource1
        '
        Me.ClienteBindingSource1.DataMember = "Cliente"
        Me.ClienteBindingSource1.DataSource = Me.Hospital1DataSet2
        '
        'ClienteTableAdapter1
        '
        Me.ClienteTableAdapter1.ClearBeforeFill = True
        '
        'ClienteBindingSource2
        '
        Me.ClienteBindingSource2.DataMember = "Cliente"
        Me.ClienteBindingSource2.DataSource = Me.Hospital1DataSet2
        '
        'ClienteBindingSource3
        '
        Me.ClienteBindingSource3.DataMember = "Cliente"
        Me.ClienteBindingSource3.DataSource = Me.Hospital1DataSet1BindingSource
        '
        'ClienteTableAdapter2
        '
        Me.ClienteTableAdapter2.ClearBeforeFill = True
        '
        'NotaBindingSource3
        '
        Me.NotaBindingSource3.DataMember = "Nota"
        Me.NotaBindingSource3.DataSource = Me.Hospital1DataSet1
        '
        'NotaBindingSource4
        '
        Me.NotaBindingSource4.DataMember = "Nota"
        Me.NotaBindingSource4.DataSource = Me.Hospital1DataSet1
        '
        'NotaBindingSource5
        '
        Me.NotaBindingSource5.DataMember = "Nota"
        Me.NotaBindingSource5.DataSource = Me.Hospital1DataSet1
        '
        'CBN
        '
        Me.CBN.DataSource = Me.NotaBindingSource9
        Me.CBN.DisplayMember = "Fecha_Emision"
        Me.CBN.FormattingEnabled = True
        Me.CBN.Location = New System.Drawing.Point(136, 282)
        Me.CBN.Name = "CBN"
        Me.CBN.Size = New System.Drawing.Size(100, 21)
        Me.CBN.TabIndex = 25
        Me.CBN.ValueMember = "ID_Factura"
        '
        'NotaBindingSource9
        '
        Me.NotaBindingSource9.DataMember = "Nota"
        Me.NotaBindingSource9.DataSource = Me.Hospital1DataSet3BindingSource
        '
        'Hospital1DataSet3BindingSource
        '
        Me.Hospital1DataSet3BindingSource.DataSource = Me.Hospital1DataSet3
        Me.Hospital1DataSet3BindingSource.Position = 0
        '
        'Hospital1DataSet3
        '
        Me.Hospital1DataSet3.DataSetName = "Hospital1DataSet3"
        Me.Hospital1DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'NotaBindingSource8
        '
        Me.NotaBindingSource8.DataMember = "Nota"
        Me.NotaBindingSource8.DataSource = Me.Hospital1DataSet1
        '
        'NotaBindingSource6
        '
        Me.NotaBindingSource6.DataMember = "Nota"
        Me.NotaBindingSource6.DataSource = Me.Hospital1DataSet1
        '
        'NotaBindingSource7
        '
        Me.NotaBindingSource7.DataMember = "Nota"
        Me.NotaBindingSource7.DataSource = Me.Hospital1DataSet1BindingSource
        '
        'NotaTableAdapter2
        '
        Me.NotaTableAdapter2.ClearBeforeFill = True
        '
        'btnVolver
        '
        Me.btnVolver.Font = New System.Drawing.Font("Lucida Sans", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVolver.Location = New System.Drawing.Point(752, 326)
        Me.btnVolver.Margin = New System.Windows.Forms.Padding(2)
        Me.btnVolver.Name = "btnVolver"
        Me.btnVolver.Size = New System.Drawing.Size(60, 24)
        Me.btnVolver.TabIndex = 45
        Me.btnVolver.Text = "Volver"
        Me.btnVolver.UseVisualStyleBackColor = True
        '
        'FrmCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(824, 361)
        Me.Controls.Add(Me.btnVolver)
        Me.Controls.Add(Me.CBN)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtTelC)
        Me.Controls.Add(Me.TxtDireccionC)
        Me.Controls.Add(Me.TxtAmC)
        Me.Controls.Add(Me.TxtApC)
        Me.Controls.Add(Me.TxtNombreC)
        Me.Controls.Add(Me.DataGridViewCliente)
        Me.Controls.Add(Me.BtnEliminarC)
        Me.Controls.Add(Me.BtnActualizarC)
        Me.Controls.Add(Me.BtnAgregar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmCliente"
        Me.Text = "FrmCliente"
        CType(Me.DataGridViewCliente, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FacturaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet3BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Hospital1DataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NotaBindingSource7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridViewCliente As DataGridView
    Friend WithEvents BtnEliminarC As Button
    Friend WithEvents BtnActualizarC As Button
    Friend WithEvents BtnAgregar As Button
    Friend WithEvents TxtNombreC As TextBox
    Friend WithEvents TxtApC As TextBox
    Friend WithEvents TxtAmC As TextBox
    Friend WithEvents TxtDireccionC As TextBox
    Friend WithEvents TxtTelC As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Hospital1DataSet As Hospital1DataSet
    Friend WithEvents ClienteBindingSource As BindingSource
    Friend WithEvents ClienteTableAdapter As Hospital1DataSetTableAdapters.ClienteTableAdapter
    Friend WithEvents FacturaBindingSource As BindingSource
    Friend WithEvents FacturaTableAdapter As Hospital1DataSetTableAdapters.FacturaTableAdapter
    Friend WithEvents Hospital1DataSetBindingSource As BindingSource
    Friend WithEvents Hospital1DataSet1 As Hospital1DataSet1
    Friend WithEvents NotaBindingSource As BindingSource
    Friend WithEvents NotaTableAdapter As Hospital1DataSet1TableAdapters.NotaTableAdapter
    Friend WithEvents Hospital1DataSet2 As Hospital1DataSet2
    Friend WithEvents NotaBindingSource1 As BindingSource
    Friend WithEvents NotaTableAdapter1 As Hospital1DataSet2TableAdapters.NotaTableAdapter
    Friend WithEvents NotaBindingSource2 As BindingSource
    Friend WithEvents ClienteBindingSource1 As BindingSource
    Friend WithEvents ClienteTableAdapter1 As Hospital1DataSet2TableAdapters.ClienteTableAdapter
    Friend WithEvents ClienteBindingSource2 As BindingSource
    Friend WithEvents Hospital1DataSet1BindingSource As BindingSource
    Friend WithEvents ClienteBindingSource3 As BindingSource
    Friend WithEvents ClienteTableAdapter2 As Hospital1DataSet1TableAdapters.ClienteTableAdapter
    Friend WithEvents IDClienteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombreCDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApPaternoCDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApMaternoCDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DireccionCDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TelefonoCDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents IDFacturaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MedicocreaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MedicoactualizaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ClienteBindingSource4 As BindingSource
    Friend WithEvents NotaBindingSource3 As BindingSource
    Friend WithEvents NotaBindingSource4 As BindingSource
    Friend WithEvents NotaBindingSource5 As BindingSource
    Friend WithEvents CBN As ComboBox
    Friend WithEvents NotaBindingSource6 As BindingSource
    Friend WithEvents NotaBindingSource7 As BindingSource
    Friend WithEvents NotaBindingSource8 As BindingSource
    Friend WithEvents Hospital1DataSet3BindingSource As BindingSource
    Friend WithEvents Hospital1DataSet3 As Hospital1DataSet3
    Friend WithEvents NotaBindingSource9 As BindingSource
    Friend WithEvents NotaTableAdapter2 As Hospital1DataSet3TableAdapters.NotaTableAdapter
    Private WithEvents btnVolver As Button
End Class
