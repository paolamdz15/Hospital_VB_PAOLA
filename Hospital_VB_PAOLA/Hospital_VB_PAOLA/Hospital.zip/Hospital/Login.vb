﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Text

Public Class Login
    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        conexionn.Open()
        Dim consulta As String = "select * from Medico where Usuario='" & txtUsuario.Text & "'and Contrasena='" + txtContrasena.Text & "'"
        Dim comando As SqlCommand = New SqlCommand(consulta, conexionn)
        Dim lector As SqlDataReader
        lector = comando.ExecuteReader()

        If lector.HasRows = True Then
            Dim frmInicio As FrmInicio = New FrmInicio()
            Me.Hide()
            frmInicio.Show()
        Else
            MessageBox.Show("Datos incorrectos")
        End If

        conexionn.Close()
    End Sub


End Class