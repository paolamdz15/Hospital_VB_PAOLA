﻿Imports System.Data.SqlClient

Module Conexion
    Public conexionn As New SqlClient.SqlConnection("data source=CELINA\SQLEXPRESS; initial catalog =Hospital1; integrated security=SSPI; persist security info = false; trusted_connection = yes; ")
End Module