﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmInicio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnFactura = New System.Windows.Forms.Button()
        Me.btnDFactura = New System.Windows.Forms.Button()
        Me.btnEnfermedad = New System.Windows.Forms.Button()
        Me.btnDiagnostico = New System.Windows.Forms.Button()
        Me.btnRecetas = New System.Windows.Forms.Button()
        Me.btnClientes = New System.Windows.Forms.Button()
        Me.btnPacientes = New System.Windows.Forms.Button()
        Me.btnTServicios = New System.Windows.Forms.Button()
        Me.btnServicios = New System.Windows.Forms.Button()
        Me.btnAtencion = New System.Windows.Forms.Button()
        Me.btnMedicamentos = New System.Windows.Forms.Button()
        Me.btnMedicos = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnFactura
        '
        Me.btnFactura.Location = New System.Drawing.Point(252, 99)
        Me.btnFactura.Name = "btnFactura"
        Me.btnFactura.Size = New System.Drawing.Size(75, 23)
        Me.btnFactura.TabIndex = 23
        Me.btnFactura.Text = "FACTURA"
        Me.btnFactura.UseVisualStyleBackColor = True
        '
        'btnDFactura
        '
        Me.btnDFactura.Location = New System.Drawing.Point(252, 70)
        Me.btnDFactura.Name = "btnDFactura"
        Me.btnDFactura.Size = New System.Drawing.Size(152, 23)
        Me.btnDFactura.TabIndex = 22
        Me.btnDFactura.Text = "DETALLE FACTURA"
        Me.btnDFactura.UseVisualStyleBackColor = True
        '
        'btnEnfermedad
        '
        Me.btnEnfermedad.Location = New System.Drawing.Point(252, 41)
        Me.btnEnfermedad.Name = "btnEnfermedad"
        Me.btnEnfermedad.Size = New System.Drawing.Size(117, 23)
        Me.btnEnfermedad.TabIndex = 21
        Me.btnEnfermedad.Text = "ENFERMEDADES"
        Me.btnEnfermedad.UseVisualStyleBackColor = True
        '
        'btnDiagnostico
        '
        Me.btnDiagnostico.Location = New System.Drawing.Point(252, 12)
        Me.btnDiagnostico.Name = "btnDiagnostico"
        Me.btnDiagnostico.Size = New System.Drawing.Size(101, 23)
        Me.btnDiagnostico.TabIndex = 20
        Me.btnDiagnostico.Text = "DIAGNOSTICOS"
        Me.btnDiagnostico.UseVisualStyleBackColor = True
        '
        'btnRecetas
        '
        Me.btnRecetas.Location = New System.Drawing.Point(155, 99)
        Me.btnRecetas.Name = "btnRecetas"
        Me.btnRecetas.Size = New System.Drawing.Size(75, 23)
        Me.btnRecetas.TabIndex = 19
        Me.btnRecetas.Text = "RECETAS"
        Me.btnRecetas.UseVisualStyleBackColor = True
        '
        'btnClientes
        '
        Me.btnClientes.Location = New System.Drawing.Point(155, 70)
        Me.btnClientes.Name = "btnClientes"
        Me.btnClientes.Size = New System.Drawing.Size(75, 23)
        Me.btnClientes.TabIndex = 18
        Me.btnClientes.Text = "CLIENTES"
        Me.btnClientes.UseVisualStyleBackColor = True
        '
        'btnPacientes
        '
        Me.btnPacientes.Location = New System.Drawing.Point(155, 41)
        Me.btnPacientes.Name = "btnPacientes"
        Me.btnPacientes.Size = New System.Drawing.Size(75, 23)
        Me.btnPacientes.TabIndex = 17
        Me.btnPacientes.Text = "PACIENTES"
        Me.btnPacientes.UseVisualStyleBackColor = True
        '
        'btnTServicios
        '
        Me.btnTServicios.Location = New System.Drawing.Point(103, 12)
        Me.btnTServicios.Name = "btnTServicios"
        Me.btnTServicios.Size = New System.Drawing.Size(143, 23)
        Me.btnTServicios.TabIndex = 16
        Me.btnTServicios.Text = "TIPOS  DE SERVICIOS"
        Me.btnTServicios.UseVisualStyleBackColor = True
        '
        'btnServicios
        '
        Me.btnServicios.Location = New System.Drawing.Point(17, 99)
        Me.btnServicios.Name = "btnServicios"
        Me.btnServicios.Size = New System.Drawing.Size(87, 23)
        Me.btnServicios.TabIndex = 15
        Me.btnServicios.Text = "SERVICIOS"
        Me.btnServicios.UseVisualStyleBackColor = True
        '
        'btnAtencion
        '
        Me.btnAtencion.Location = New System.Drawing.Point(17, 70)
        Me.btnAtencion.Name = "btnAtencion"
        Me.btnAtencion.Size = New System.Drawing.Size(87, 23)
        Me.btnAtencion.TabIndex = 14
        Me.btnAtencion.Text = "ATENCION"
        Me.btnAtencion.UseVisualStyleBackColor = True
        '
        'btnMedicamentos
        '
        Me.btnMedicamentos.Location = New System.Drawing.Point(17, 41)
        Me.btnMedicamentos.Name = "btnMedicamentos"
        Me.btnMedicamentos.Size = New System.Drawing.Size(103, 23)
        Me.btnMedicamentos.TabIndex = 13
        Me.btnMedicamentos.Text = "MEDICAMENTOS"
        Me.btnMedicamentos.UseVisualStyleBackColor = True
        '
        'btnMedicos
        '
        Me.btnMedicos.Location = New System.Drawing.Point(17, 12)
        Me.btnMedicos.Name = "btnMedicos"
        Me.btnMedicos.Size = New System.Drawing.Size(75, 23)
        Me.btnMedicos.TabIndex = 12
        Me.btnMedicos.Text = "MEDICOS"
        Me.btnMedicos.UseVisualStyleBackColor = True
        '
        'FrmInicio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(629, 364)
        Me.Controls.Add(Me.btnFactura)
        Me.Controls.Add(Me.btnDFactura)
        Me.Controls.Add(Me.btnEnfermedad)
        Me.Controls.Add(Me.btnDiagnostico)
        Me.Controls.Add(Me.btnRecetas)
        Me.Controls.Add(Me.btnClientes)
        Me.Controls.Add(Me.btnPacientes)
        Me.Controls.Add(Me.btnTServicios)
        Me.Controls.Add(Me.btnServicios)
        Me.Controls.Add(Me.btnAtencion)
        Me.Controls.Add(Me.btnMedicamentos)
        Me.Controls.Add(Me.btnMedicos)
        Me.Name = "FrmInicio"
        Me.Text = "FrmInicio"
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents btnFactura As Button
    Private WithEvents btnDFactura As Button
    Private WithEvents btnEnfermedad As Button
    Private WithEvents btnDiagnostico As Button
    Private WithEvents btnRecetas As Button
    Private WithEvents btnClientes As Button
    Private WithEvents btnPacientes As Button
    Private WithEvents btnTServicios As Button
    Private WithEvents btnServicios As Button
    Private WithEvents btnAtencion As Button
    Private WithEvents btnMedicamentos As Button
    Private WithEvents btnMedicos As Button
End Class
